#!/usr/bin/env python3
"""Repair the Sky's the Limit sequential TDD JSONL execution graph.

This compiler preserves the original source records, reconciles completed live
repository state, inserts a mandatory audit-remediation gate, makes all
synthetic ordering dependencies explicit, computes a dependency-safe sequential
order, and regenerates the executable edge layer.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

PROGRAM_ID = "stl-post-g20-sequential-tdd-v1"
SCHEMA_VERSION = "1.1.0"
CURRENT_HEAD = "5eb385d33976503cdac81e982ed74fbbc7f6839c"

HISTORICAL_NODES = {
    "G20-FOUNDATION-READY",
    "B25-001", "B25-002", "B25-003", "B25-004", "B25-005",
    "B25-006", "B25-007", "B25-008", "B25-009",
    "G25-DESIGN-GOVERNANCE-READY",
    "PR-001-OPEN-DRAFT",
}

BLOCKED_PRE_PRODUCTION_NODES = {
    "STL-504", "STL-505",
    "G70-CUTOVER-READY", "G80-CUTOVER-COMPLETE",
    "G85-ROLLBACK-WINDOW-CLEARED", "G90-DECOMMISSIONED",
    "STOP-PRE-G70",
}

SYNTHETIC_PAIRS = [
    ("G20-FOUNDATION-READY", "B25-001"),
    ("B25-001", "B25-002"),
    ("B25-002", "B25-003"),
    ("B25-003", "B25-004"),
    ("B25-004", "B25-005"),
    ("B25-005", "B25-006"),
    ("B25-006", "B25-007"),
    ("B25-007", "B25-008"),
    ("B25-008", "B25-009"),
    ("B25-009", "G25-DESIGN-GOVERNANCE-READY"),
    ("G25-DESIGN-GOVERNANCE-READY", "PR-001-OPEN-DRAFT"),
    ("PR-001-OPEN-DRAFT", "AUDIT-SECURITY-REMEDIATION"),
    ("AUDIT-SECURITY-REMEDIATION", "AUDIT-REPOSITORY-HYGIENE"),
    ("AUDIT-REPOSITORY-HYGIENE", "G26-AUDIT-REMEDIATION-READY"),
    ("G26-AUDIT-REMEDIATION-READY", "ORCH-001"),
    ("ORCH-001", "ORCH-002"),
    ("ORCH-002", "ORCH-003"),
    ("ORCH-003", "ORCH-004"),
    ("G70-PACKET-ASSEMBLE", "STOP-PRE-G70"),
]

AGENT_STAGES = [
    ("acquire_writer_mutex", "agent:orchestrator", "none", False, 1),
    ("verify_worktree", "agent:release-manager", "repository_read", False, 1),
    ("plan", "agent:orchestrator", "evidence_only", False, 5),
    ("discover", "agent:researcher", "none", False, 8),
    ("issue_decision", "agent:orchestrator", "issue_metadata_only", False, 1),
    ("cost_plan", "agent:cost-controller", "evidence_only", False, 2),
    ("write_red_test", "agent:writer", "test_code", True, 10),
    ("verify_red_failure", "agent:test-verifier", "none", False, 4),
    ("implement", "agent:writer", "implementation_code", True, 30),
    ("verify_green", "agent:test-verifier", "none", False, 8),
    ("scoped_verify", "agent:test-verifier", "none", False, 8),
    ("cost_verify", "agent:cost-controller", "evidence_only", False, 3),
    ("independent_review", "agent:reviewer", "review_comments_only", False, 6),
    ("repair_review_findings", "agent:writer", "conditional_code_repair", True, 5),
    ("commit", "agent:release-manager", "git_commit", True, 2),
    ("push", "agent:release-manager", "git_push", True, 1),
    ("update_draft_pr", "agent:release-manager", "pr_metadata", True, 1),
    ("verify_pr_ci", "agent:test-verifier", "none", False, 2),
    ("release_writer_mutex", "agent:orchestrator", "none", False, 1),
    ("complete", "agent:orchestrator", "ledger_only", False, 1),
]

GATE_STAGES = [
    ("collect_evidence", "agent:orchestrator", "evidence_only", False, 25),
    ("independent_verify", "agent:reviewer", "review_comments_only", False, 20),
    ("verify_github_checks", "agent:test-verifier", "none", False, 20),
    ("verify_vercel_preview", "agent:test-verifier", "none", False, 20),
    ("update_ledgers", "agent:orchestrator", "ledger_only", False, 10),
    ("complete", "agent:orchestrator", "ledger_only", False, 5),
]


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            row.pop("_line", None)
            rows.append(row)
    return rows


def dump_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def add_dep(nodes: dict[str, dict[str, Any]], parent: str, child: str) -> None:
    deps = nodes[child].setdefault("dependsOn", [])
    if parent not in deps:
        deps.append(parent)


def make_node(
    node_id: str,
    title: str,
    node_type: str,
    objective: str,
    depends_on: list[str],
    *,
    risk: str,
    tdd: bool,
    security_review: bool,
    expected_usd: float,
    high_usd: float,
    labor_hours: float,
    required_skills: list[str],
    required_tools: list[str],
    initial_files: list[str],
    verification_hints: list[str],
) -> dict[str, Any]:
    return {
        "recordId": f"node:{node_id}",
        "recordType": "node",
        "nodeId": node_id,
        "title": title,
        "nodeType": node_type,
        "batch": "B26",
        "status": "pending",
        "sequentialRank": None,
        "risk": risk,
        "objective": objective,
        "dependsOn": depends_on,
        "requiredSkills": required_skills,
        "requiredTools": required_tools,
        "initialFiles": initial_files,
        "verificationHints": verification_hints,
        "sourceVerification": {
            "checks": verification_hints,
            "requiredEvidence": [
                "focused red-green test evidence",
                "independent review",
                "GitHub check evidence",
                "Vercel preview evidence",
            ],
            "successCondition": "All stated findings are closed with executable evidence and no production mutation.",
            "independent": True,
        },
        "sourceFailurePolicy": {
            "retryOn": ["transient_connector_failure"],
            "stopOn": ["unresolved_p0", "unresolved_p1", "test_regression", "preview_failure"],
            "fallbackNode": None,
        },
        "tddRequired": tdd,
        "redTestRequired": tdd,
        "independentReviewRequired": True,
        "securityReviewRequired": security_review,
        "worktree": {
            "default": "governed_integration_worktree",
            "ephemeralAllowed": False,
            "mainCheckoutMutation": False,
        },
        "issueAction": "update_existing_pr_review_findings",
        "prAction": "keep_draft_until_gate_passes",
        "costBudget": {
            "aiUsdExpected": expected_usd,
            "aiUsdHigh": high_usd,
            "laborHoursExpected": labor_hours,
            "infrastructureUsd": 0.0,
            "externalUsd": 0.0,
        },
        "costWarningPercent": 70,
        "costHardStopPercent": 95,
        "maxAttempts": 2,
        "productionSideEffectsAllowed": False,
        "schemaVersion": SCHEMA_VERSION,
        "programId": PROGRAM_ID,
    }


def make_stages(node: dict[str, Any], stage_template: list[tuple[str, str, str, bool, int]]) -> list[dict[str, Any]]:
    total = node["costBudget"]
    stages = []
    for ordinal, (name, owner, mutation, mutex, weight) in enumerate(stage_template, 1):
        factor = weight / 100.0
        stages.append({
            "recordId": f"stage:{node['nodeId']}:{name}",
            "recordType": "stage",
            "stageId": f"stage:{node['nodeId']}:{name}",
            "nodeId": node["nodeId"],
            "stage": name,
            "ordinal": ordinal,
            "status": "pending",
            "ownerAgent": owner,
            "mutationClass": mutation,
            "writerMutexRequired": mutex,
            "costWeightPercent": weight,
            "stageBudget": {
                "aiUsdExpected": round(total["aiUsdExpected"] * factor, 6),
                "aiUsdHigh": round(total["aiUsdHigh"] * factor, 6),
                "laborHoursExpected": round(total["laborHoursExpected"] * factor, 6),
                "infrastructureUsd": 0.0,
                "externalUsd": 0.0,
            },
            "entryCriteria": ["previous stage complete"],
            "exitCriteria": ["stage evidence recorded"],
            "evidencePath": f".agents/evidence/nodes/{node['nodeId']}/{name}.json",
            "schemaVersion": SCHEMA_VERSION,
            "programId": PROGRAM_ID,
        })
    return stages


def make_test_contract(node_id: str) -> dict[str, Any]:
    return {
        "recordId": f"test-contract:{node_id}",
        "recordType": "test_contract",
        "nodeId": node_id,
        "testFirst": True,
        "redStage": f"stage:{node_id}:verify_red_failure",
        "implementationStage": f"stage:{node_id}:implement",
        "greenStage": f"stage:{node_id}:verify_green",
        "redMustFail": True,
        "redFailureMustBe": "expected assertion failure caused by missing or incorrect behavior",
        "redFailureMustNotBe": [
            "syntax error", "dependency missing", "provider account mismatch",
            "network outage", "unrelated fixture failure", "test not discovered",
        ],
        "greenMustUseSameTest": True,
        "testWeakeningForbidden": True,
        "focusedBeforeFull": True,
        "schemaVersion": SCHEMA_VERSION,
        "programId": PROGRAM_ID,
    }


def make_cost_test(node: dict[str, Any]) -> dict[str, Any]:
    node_id = node["nodeId"]
    return {
        "recordId": f"cost-test:{node_id}",
        "recordType": "cost_test",
        "nodeId": node_id,
        "runsAfter": f"stage:{node_id}:scoped_verify",
        "blocksBefore": f"stage:{node_id}:independent_review",
        "assertions": {
            "aiUsdActualLteHighBudget": node["costBudget"]["aiUsdHigh"],
            "actualVsExpectedDeviationPercentLte": 50,
            "writerAgentsLte": 1,
            "readOnlyAgentsLte": 2,
            "waitOperationsLte": 10,
            "identicalToolCallRetriesLte": 2,
            "implementationAttemptsLte": 2,
            "graphifyContextBudgetTokensLte": 1500,
            "initialSourceFilesLte": max(3, len(node["initialFiles"])),
            "completeLogsStoredAsArtifacts": True,
        },
        "onFailure": "enter loop:cost-optimize; after two failures block and replan",
        "schemaVersion": SCHEMA_VERSION,
        "programId": PROGRAM_ID,
    }


def topo_sort(nodes: dict[str, dict[str, Any]], runnable: set[str], old_rank: dict[str, int | None]) -> list[str]:
    indegree = {node_id: 0 for node_id in runnable}
    children: dict[str, list[str]] = defaultdict(list)
    for child in runnable:
        for parent in nodes[child].get("dependsOn", []):
            if parent in runnable:
                indegree[child] += 1
                children[parent].append(child)

    def key(node_id: str) -> tuple[int, str]:
        rank = old_rank.get(node_id)
        return (rank if isinstance(rank, int) else 10**9, node_id)

    ready = sorted((n for n, degree in indegree.items() if degree == 0), key=key)
    order: list[str] = []
    while ready:
        current = ready.pop(0)
        order.append(current)
        for child in sorted(children[current], key=key):
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
                ready.sort(key=key)
    if len(order) != len(runnable):
        stuck = sorted(set(runnable) - set(order))
        raise RuntimeError(f"dependency cycle remains among runnable nodes: {stuck}")
    return order


def build_schema() -> dict[str, Any]:
    types = [
        "acceptance_criterion", "agent", "batch", "cost_test", "edge",
        "execution_cursor", "loop", "node", "policy", "program", "rule",
        "source", "source_edge", "stage", "state_snapshot", "stop_condition",
        "telemetry_baseline", "test_contract",
    ]
    common_properties: dict[str, Any] = {
        "recordId": {"type": "string", "minLength": 1},
        "recordType": {"type": "string", "enum": types},
        "schemaVersion": {"const": SCHEMA_VERSION},
        "programId": {"const": PROGRAM_ID},
        "nodeId": {"type": "string", "minLength": 1},
        "stageId": {"type": "string", "minLength": 1},
        "title": {"type": "string"},
        "status": {"type": "string"},
        "dependsOn": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "sequentialRank": {"type": ["integer", "null"], "minimum": 1},
        "ordinal": {"type": "integer", "minimum": 1},
        "from": {"type": "string"},
        "to": {"type": "string"},
        "required": {"type": "boolean"},
        "mandatory": {"type": "boolean"},
    }
    required_by_type = {
        "program": ["title", "generatedAt", "repository", "branch", "currentHead", "resumeGate", "executionMode", "globalWriterLimit", "draftPrPolicy", "stopBefore"],
        "source": ["path", "sha256", "trust"],
        "state_snapshot": ["branch", "currentHead", "remoteMain", "currentGate", "currentGateStatus", "vercelLatestIntegrationDeployment", "productionMutationAuthorized"],
        "telemetry_baseline": ["source", "jsonlRecords", "totalTokens", "purpose"],
        "agent": ["role", "mayMutate", "purpose", "concurrency"],
        "rule": ["ruleId", "name", "mandatory", "text"],
        "policy": ["policyType"],
        "loop": ["name", "entry", "steps", "maxIterations", "exit"],
        "batch": ["id", "title", "order", "status", "productionSideEffects", "writerLimit", "readOnlyAgentLimit", "sequential"],
        "node": ["nodeId", "title", "nodeType", "batch", "status", "sequentialRank", "risk", "objective", "dependsOn", "tddRequired", "redTestRequired", "independentReviewRequired", "productionSideEffectsAllowed"],
        "stage": ["stageId", "nodeId", "stage", "ordinal", "status", "ownerAgent", "mutationClass", "writerMutexRequired", "costWeightPercent", "stageBudget", "evidencePath"],
        "edge": ["edgeType", "from", "to", "required", "condition"],
        "test_contract": ["nodeId", "testFirst", "redStage", "implementationStage", "greenStage", "redMustFail", "greenMustUseSameTest", "testWeakeningForbidden"],
        "cost_test": ["nodeId", "runsAfter", "blocksBefore", "assertions", "onFailure"],
        "source_edge": ["sourceEdgeId", "fromNode", "toNode", "kind", "condition", "required", "preserved"],
        "acceptance_criterion": ["criterionId", "criterion", "evidenceRequired"],
        "execution_cursor": ["currentNode", "currentStage", "nextOnSuccess", "blockedReason", "automaticExecutionAllowedAfterApproval", "productionExecutionAllowed"],
        "stop_condition": ["nodeId", "mandatory", "triggers", "resumeRequires"],
    }
    all_of = []
    for record_type, required in required_by_type.items():
        all_of.append({
            "if": {"properties": {"recordType": {"const": record_type}}, "required": ["recordType"]},
            "then": {"required": required},
        })
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "https://example.invalid/skys-limit-sequential-tdd-execution-graph-audited.schema.json",
        "title": "Sky's the Limit Audited Sequential TDD JSONL Record",
        "type": "object",
        "required": ["recordId", "recordType", "schemaVersion", "programId"],
        "properties": common_properties,
        "allOf": all_of,
        "additionalProperties": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--schema-output", type=Path, required=True)
    parser.add_argument("--vercel-deployment-id", default="dpl_DPZH2TV321b8nJj4UAUNE6GEtw1W")
    parser.add_argument("--vercel-state", default="BUILDING")
    args = parser.parse_args()

    original = load_jsonl(args.input)
    by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in original:
        by_type[row["recordType"]].append(copy.deepcopy(row))

    now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    for rows in by_type.values():
        for row in rows:
            row["schemaVersion"] = SCHEMA_VERSION
            row["programId"] = PROGRAM_ID

    program = by_type["program"][0]
    program.update({
        "generatedAt": now,
        "currentHead": CURRENT_HEAD,
        "resumeGate": "G26-AUDIT-REMEDIATION-READY",
        "instruction": "Execute only the audited dependency-safe sequence; keep PR 169 draft and stop before production approval.",
    })

    state = by_type["state_snapshot"][0]
    state.update({
        "currentHead": CURRENT_HEAD,
        "worktree": "github_branch_audited_desktop_commander_unavailable",
        "currentGate": "G26-AUDIT-REMEDIATION-READY",
        "currentGateStatus": "blocked_on_open_security_review_and_repository_hygiene_findings",
        "vercelLatestIntegrationDeployment": {
            "id": args.vercel_deployment_id,
            "state": args.vercel_state,
            "head": CURRENT_HEAD,
            "previousVerifiedReadyHead": "3b46b4ae0c503fc539ef43bb5b98f9bdbf72b04e",
            "previousVerifiedReadyDeployment": "dpl_3Z4TUBHXNPPciiy8ijvxLpvWwvF1",
            "rootCause": "active multi-service packaging removed from production-linked Next.js project",
        },
        "productionMutationAuthorized": False,
    })

    cursor = by_type["execution_cursor"][0]
    cursor.update({
        "currentNode": "AUDIT-SECURITY-REMEDIATION",
        "currentStage": "stage:AUDIT-SECURITY-REMEDIATION:write_red_test",
        "nextOnSuccess": "AUDIT-REPOSITORY-HYGIENE",
        "blockedReason": "PR 169 has unresolved P0-P2 review findings; no merge or production action is allowed.",
        "exactApprovalText": "",
        "automaticExecutionAllowedAfterApproval": False,
        "productionExecutionAllowed": False,
    })

    batches = {row["id"]: row for row in by_type["batch"]}
    batch_order = {
        "HISTORICAL": 0, "G20": 1, "B25": 2, "PR": 3,
        "B26": 4, "ORCH": 5, "B31": 6, "B30": 7,
        "B50": 8, "B60": 9, "STOP": 10,
    }
    for batch_id in ("G20", "B25", "PR"):
        batches[batch_id]["status"] = "historical_complete_do_not_replay"
    for batch_id, order in batch_order.items():
        if batch_id in batches:
            batches[batch_id]["order"] = order
    if "B26" not in batches:
        batches["B26"] = {
            "recordId": "batch:B26",
            "recordType": "batch",
            "id": "B26",
            "title": "Audit remediation and merge-safety gate",
            "order": 4,
            "status": "pending",
            "productionSideEffects": False,
            "writerLimit": 1,
            "readOnlyAgentLimit": 2,
            "sequential": True,
            "schemaVersion": SCHEMA_VERSION,
            "programId": PROGRAM_ID,
        }
    by_type["batch"] = sorted(batches.values(), key=lambda row: (row["order"], row["id"]))

    nodes = {row["nodeId"]: row for row in by_type["node"]}
    old_rank = {node_id: row.get("sequentialRank") for node_id, row in nodes.items()}
    # Live audit remediation is the mandatory resume boundary. Give inserted
    # nodes priority ahead of all still-pending product work while dependencies
    # continue to provide the hard correctness constraint.
    old_rank.update({
        "AUDIT-SECURITY-REMEDIATION": -3,
        "AUDIT-REPOSITORY-HYGIENE": -2,
        "G26-AUDIT-REMEDIATION-READY": -1,
    })

    security = make_node(
        "AUDIT-SECURITY-REMEDIATION",
        "Remediate active PR security and runtime findings",
        "agent",
        "Triage every unresolved CodeQL and review P0-P2 finding, write focused failing regressions first, fix or remove unsafe executable paths without broad suppression, and prove GitHub security checks are clean.",
        ["PR-001-OPEN-DRAFT"],
        risk="high", tdd=True, security_review=True,
        expected_usd=8.0, high_usd=20.0, labor_hours=8.0,
        required_skills=["receiving-code-review", "systematic-debugging", "test-driven-development", "security-verification", "verification-before-completion"],
        required_tools=["GitHub connector", "Context7", "Convex", "Vercel", "Desktop Commander when connected"],
        initial_files=["tests/convex-deployment-command.test.mjs", ".github/workflows/security.yml", ".agents/skills/**", ".github/skills/**"],
        verification_hints=["all current P0/P1/P2 review threads triaged", "focused red-green tests", "CodeQL and security workflow pass", "no broad CodeQL suppression"],
    )
    hygiene = make_node(
        "AUDIT-REPOSITORY-HYGIENE",
        "Repair repository hygiene and portable evidence",
        "agent",
        "Remove generated bytecode and unsafe repository artifacts, reject nested Git metadata, sanitize machine-specific paths and raw PII from committed evidence, and verify the branch is portable and secret-free.",
        ["AUDIT-SECURITY-REMEDIATION"],
        risk="medium", tdd=True, security_review=True,
        expected_usd=3.0, high_usd=8.0, labor_hours=4.0,
        required_skills=["systematic-debugging", "test-driven-development", "security-verification", "verification-before-completion"],
        required_tools=["GitHub connector", "Desktop Commander when connected", "secret scanner", "git"],
        initial_files=[".gitignore", ".agents/goals/**/verify-last.json", ".agents/skills/**", ".github/skills/**"],
        verification_hints=["no tracked __pycache__ or pyc", "no nested .git metadata", "no committed secret material", "no machine-specific PII paths", "git diff --check passes"],
    )
    gate = make_node(
        "G26-AUDIT-REMEDIATION-READY",
        "Security, preview, and graph remediation passed",
        "validator",
        "Close the merge-safety gate only when security review, repository hygiene, dependency-safe graph validation, GitHub checks, and a Vercel Preview for the exact head all pass.",
        ["AUDIT-REPOSITORY-HYGIENE"],
        risk="high", tdd=False, security_review=True,
        expected_usd=1.0, high_usd=3.0, labor_hours=2.0,
        required_skills=["requesting-code-review", "security-verification", "verification-before-completion"],
        required_tools=["GitHub connector", "Vercel", "Convex", "execution-ledger"],
        initial_files=[".graph/**", ".github/workflows/**", "vercel.json", "convex/**", "tests/**"],
        verification_hints=["semantic graph validator passes", "GitHub required checks pass", "exact-head Vercel Preview is READY", "PR remains draft until all blockers close"],
    )
    nodes[security["nodeId"]] = security
    nodes[hygiene["nodeId"]] = hygiene
    nodes[gate["nodeId"]] = gate

    for node_id in HISTORICAL_NODES:
        if node_id in nodes:
            nodes[node_id]["status"] = "historical_complete_do_not_replay"
            nodes[node_id]["sequentialRank"] = None

    for node_id in BLOCKED_PRE_PRODUCTION_NODES:
        if node_id in nodes:
            nodes[node_id]["status"] = "blocked_requires_new_explicit_approval"
            nodes[node_id]["sequentialRank"] = None

    for node in nodes.values():
        node["dependsOn"] = list(dict.fromkeys(node.get("dependsOn", [])))

    # Replace obsolete synthetic sequencing with dependency-truth sequencing.
    for parent, child in SYNTHETIC_PAIRS:
        add_dep(nodes, parent, child)

    # B25 and PR are completed history and must not depend on unfinished ORCH work.
    for child in ["B25-001"]:
        nodes[child]["dependsOn"] = [d for d in nodes[child]["dependsOn"] if d != "ORCH-004"]
    # G26 owns the transition into ORCH; remove the stale direct G20 transition.
    nodes["ORCH-001"]["dependsOn"] = [d for d in nodes["ORCH-001"]["dependsOn"] if d != "G20-FOUNDATION-READY"]
    add_dep(nodes, "G26-AUDIT-REMEDIATION-READY", "ORCH-001")

    # A cutover packet may be assembled only from the completed pre-production gates.
    nodes["G70-PACKET-ASSEMBLE"]["dependsOn"] = [
        "G30-PUBLIC-CMS-READY",
        "G31-VISITOR-TO-BOOKING",
        "G40-PROPOSAL-TO-DEPOSIT",
        "G50-PORTAL-OPS-READY",
        "G60-MEASUREMENT-READY",
        "STL-506",
    ]
    nodes["STOP-PRE-G70"]["dependsOn"] = ["G70-PACKET-ASSEMBLE"]

    runnable = {node_id for node_id, node in nodes.items() if node["status"] == "pending"}
    order = topo_sort(nodes, runnable, old_rank)
    for node in nodes.values():
        node["sequentialRank"] = None
    for rank, node_id in enumerate(order, 1):
        nodes[node_id]["sequentialRank"] = rank

    stages_by_node: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for stage in by_type["stage"]:
        stages_by_node[stage["nodeId"]].append(stage)
    stages_by_node[security["nodeId"]] = make_stages(security, AGENT_STAGES)
    stages_by_node[hygiene["nodeId"]] = make_stages(hygiene, AGENT_STAGES)
    stages_by_node[gate["nodeId"]] = make_stages(gate, GATE_STAGES)

    for node_id, node in nodes.items():
        node_status = node["status"]
        for stage in stages_by_node[node_id]:
            if node_status == "historical_complete_do_not_replay":
                stage["status"] = "historical_complete_do_not_replay"
            elif node_status.startswith("blocked"):
                stage["status"] = "blocked"
            else:
                stage["status"] = "pending"
            stage["schemaVersion"] = SCHEMA_VERSION
            stage["programId"] = PROGRAM_ID

    # Replace test and cost contracts only for inserted TDD nodes; preserve originals.
    tests = {row["nodeId"]: row for row in by_type["test_contract"]}
    costs = {row["nodeId"]: row for row in by_type["cost_test"]}
    for node in (security, hygiene):
        tests[node["nodeId"]] = make_test_contract(node["nodeId"])
        costs[node["nodeId"]] = make_cost_test(node)

    # Rules make the missing semantic guarantees explicit.
    rules = {row["ruleId"]: row for row in by_type["rule"]}
    extra_rules = [
        ("R029", "compiled_dag", "The executable stage graph must be acyclic; schema validity alone is insufficient."),
        ("R030", "topological_rank", "Every sequential rank must respect all explicit and synthetic dependencies."),
        ("R031", "review_findings_block_merge", "Any unresolved P0, P1, or P2 security or architecture finding keeps the PR draft and blocks merge."),
        ("R032", "exact_head_preview", "The exact reviewed head must have a successful Vercel Preview before the PR can be marked ready."),
    ]
    for rule_id, name, text in extra_rules:
        rules[rule_id] = {
            "recordId": f"rule:{rule_id}", "recordType": "rule",
            "ruleId": rule_id, "name": name, "mandatory": True, "text": text,
            "schemaVersion": SCHEMA_VERSION, "programId": PROGRAM_ID,
        }
    by_type["rule"] = sorted(rules.values(), key=lambda row: row["ruleId"])

    criteria = {row["criterionId"]: row for row in by_type["acceptance_criterion"]}
    for criterion_id, criterion, evidence in [
        ("ac-g26-security-clean", "All current PR P0-P2 findings are closed or independently dispositioned with executable evidence", ["CodeQL pass", "review-thread ledger", "focused regressions"]),
        ("ac-g26-preview-ready", "The exact reviewed head has a successful protected Vercel Preview", ["deployment ID", "head SHA", "build logs", "route smoke"]),
        ("ac-g26-graph-valid", "The schema and semantic validator both pass and the stage graph is acyclic", ["validator output", "topological order", "record hash"]),
    ]:
        criteria[criterion_id] = {
            "recordId": f"acceptance:{criterion_id}", "recordType": "acceptance_criterion",
            "criterionId": criterion_id, "criterion": criterion, "evidenceRequired": evidence,
            "schemaVersion": SCHEMA_VERSION, "programId": PROGRAM_ID,
        }
    by_type["acceptance_criterion"] = sorted(criteria.values(), key=lambda row: row["criterionId"])

    # Normalize schema/program version on every preserved record after modifications.
    for row in nodes.values():
        row["schemaVersion"] = SCHEMA_VERSION
        row["programId"] = PROGRAM_ID
    by_type["node"] = sorted(nodes.values(), key=lambda row: row["nodeId"])
    by_type["stage"] = [
        stage
        for node_id in sorted(stages_by_node)
        for stage in sorted(stages_by_node[node_id], key=lambda row: row["ordinal"])
    ]
    by_type["test_contract"] = sorted(tests.values(), key=lambda row: row["nodeId"])
    by_type["cost_test"] = sorted(costs.values(), key=lambda row: row["nodeId"])

    stage_lists = {node_id: sorted(items, key=lambda row: row["ordinal"]) for node_id, items in stages_by_node.items()}
    first_stage = {node_id: items[0]["stageId"] for node_id, items in stage_lists.items()}
    last_stage = {node_id: items[-1]["stageId"] for node_id, items in stage_lists.items()}

    edges: list[dict[str, Any]] = []
    for node_id in sorted(stage_lists):
        items = stage_lists[node_id]
        for left, right in zip(items, items[1:]):
            edges.append({
                "recordId": f"edge:stage:{node_id}:{left['ordinal']:02d}-{right['ordinal']:02d}",
                "recordType": "edge", "edgeType": "stage_sequence",
                "from": left["stageId"], "to": right["stageId"],
                "required": True, "condition": "previous_stage_passed",
                "schemaVersion": SCHEMA_VERSION, "programId": PROGRAM_ID,
            })

    source_conditions = {
        (row["fromNode"], row["toNode"]): row.get("condition", "requires")
        for row in by_type["source_edge"]
    }
    synthetic_set = set(SYNTHETIC_PAIRS)
    dependency_pairs = sorted(
        ((parent, child) for child, node in nodes.items() for parent in node.get("dependsOn", [])),
        key=lambda pair: (pair[1], pair[0]),
    )
    dep_counter = 0
    syn_counter = 0
    for parent, child in dependency_pairs:
        if (parent, child) in synthetic_set:
            syn_counter += 1
            edge_type = "synthetic_dependency"
            record_id = f"edge:synthetic:{syn_counter:03d}"
            condition = "requires"
        else:
            dep_counter += 1
            edge_type = "node_dependency"
            record_id = f"edge:dependency:{dep_counter:04d}"
            condition = source_conditions.get((parent, child), "requires")
        edges.append({
            "recordId": record_id, "recordType": "edge", "edgeType": edge_type,
            "from": last_stage[parent], "to": first_stage[child],
            "required": True, "condition": condition,
            "schemaVersion": SCHEMA_VERSION, "programId": PROGRAM_ID,
        })

    for serial, (left, right) in enumerate(zip(order, order[1:]), 1):
        edges.append({
            "recordId": f"edge:serialize:{serial:03d}", "recordType": "edge",
            "edgeType": "global_serialization", "from": last_stage[left], "to": first_stage[right],
            "required": True, "condition": "global_previous_node_complete",
            "writerMutex": "GLOBAL-STL-WRITER",
            "schemaVersion": SCHEMA_VERSION, "programId": PROGRAM_ID,
        })
    by_type["edge"] = edges

    # Telemetry is a source baseline. Add compiler output counts without changing the measured source values.
    telemetry = by_type["telemetry_baseline"][0]
    telemetry["purpose"] = telemetry.get("purpose", "") + " Audited compiler adds semantic DAG, rank, cursor, and gate validation."

    type_order = [
        "program", "source", "state_snapshot", "telemetry_baseline", "agent",
        "rule", "policy", "loop", "batch", "node", "stage", "edge",
        "test_contract", "cost_test", "source_edge", "acceptance_criterion",
        "execution_cursor", "stop_condition",
    ]
    output: list[dict[str, Any]] = []
    for record_type in type_order:
        output.extend(by_type[record_type])

    # Final metadata that depends on output size.
    telemetry["auditedJsonlRecords"] = len(output)
    telemetry["auditedNodeCount"] = len(by_type["node"])
    telemetry["auditedStageCount"] = len(by_type["stage"])
    telemetry["auditedEdgeCount"] = len(by_type["edge"])
    telemetry["auditedRunnableNodeCount"] = len(order)

    dump_jsonl(args.output, output)
    schema = build_schema()
    args.schema_output.write_text(json.dumps(schema, indent=2) + "\n", encoding="utf-8")

    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    print(json.dumps({
        "ok": True,
        "output": str(args.output),
        "schema": str(args.schema_output),
        "sha256": digest,
        "records": len(output),
        "nodes": len(by_type["node"]),
        "stages": len(by_type["stage"]),
        "edges": len(by_type["edge"]),
        "runnableOrder": order,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
