# Sky's the Limit Sequential TDD Execution Graph — Audit and Remediation

**Audit date:** 2026-07-28  
**Repository:** `skysthelimitpainting1779-collab/skys-the-limit-painting-llc-website`  
**Integration branch:** `agent/skys-limit-convex-os`  
**Audited head:** `5eb385d33976503cdac81e982ed74fbbc7f6839c`  
**Pull request:** `#169` — open, mergeable, and draft  
**Production mutation authorization:** `false`

## Executive result

The supplied bundle was structurally parseable, but its validator only established a shallow record-shape result. It did not prove that the executable stage graph was acyclic, that the sequential ranks respected dependencies, that the cursor matched live repository state, or that blocked production nodes were excluded from execution.

The original graph fails the new semantic validator with **36 errors**. The repaired graph passes with:

- **0 JSON parse errors**
- **0 JSON Schema errors**
- **0 semantic errors**
- **86 nodes**
- **1,496 stages**
- **1,669 executable edges**
- **43 dependency-safe runnable nodes**
- SHA-256: `55ea584c610404c089c9058ae3abd8a17bacac15b6c0fa0887f4fbc47a789b43`

## Tools and authoritative surfaces used

- **Uploaded graph bundle:** source JSONL, schema, and prior validation output.
- **GitHub:** repository, branch, PR, files, current head, unresolved review threads, and branch writes.
- **Vercel:** project configuration, deployment history, exact-head Preview status, and build logs.
- **Convex:** official integration/scaling guidance plus live Vercel build evidence for the selected Preview deployment.
- **Context7:** current official Convex, Next.js 16, and Hono deployment documentation.
- **Desktop Commander:** attempted, but no authorized desktop device was connected. No claim is made that the local Windows checkout was inspected.

## Critical graph defects found

### 1. Executable graph cycles

The source `node.dependsOn` graph was acyclic, but compiler-added global serialization edges created two strongly connected executable components:

1. **124 stages across 9 nodes**
   - `G60-MEASUREMENT-READY`
   - `G70-CUTOVER-READY`
   - `G80-CUTOVER-COMPLETE`
   - `G85-ROLLBACK-WINDOW-CLEARED`
   - `STL-502`, `STL-503`, `STL-504`, `STL-505`, `STL-506`

2. **212 stages across 12 nodes**
   - `G31-VISITOR-TO-BOOKING`
   - `G40-PROPOSAL-TO-DEPOSIT`
   - `STL-201` through `STL-209`
   - `STL-301`

A mandatory sequential executor could deadlock or wait forever inside either component.

### 2. Rank order contradicted dependencies

Examples from the original graph:

- `STL-301` was rank 28 but was a dependency of nodes ranked 17, 18, 20, and 22.
- `G60-MEASUREMENT-READY` was rank 53 but was a dependency of `STL-506` at rank 49.
- `STOP-PRE-G70` was blocked but still ranked as executable.
- `STL-504` and `STL-505` depended on production approval gates but remained pending and ranked.

### 3. Dependency truth was split across incompatible layers

Seventeen synthetic dependency edges existed only in the executable edge layer and were absent from `node.dependsOn`. One declared dependency lacked its executable edge. This allowed metadata, scheduling, and validation to disagree.

### 4. Cursor and completion state were stale

The graph still waited at `G20-FOUNDATION-READY`, although repository evidence records G20 approval, B25 completion, and the open draft PR. Replaying those nodes would waste cost and risk duplicate side effects.

### 5. Cutover packet had no readiness dependencies

`G70-PACKET-ASSEMBLE` had an empty dependency list. It could be scheduled without the public CMS, booking, proposal/deposit, portal, measurement, or cutover-runbook readiness gates.

### 6. Schema was too permissive

The original schema required only four generic fields and allowed arbitrary additional properties. It did not impose record-type requirements or validate graph semantics.

## Graph repairs applied

1. Reconciled live state:
   - G20, all B25 nodes, the B25 gate, and `PR-001-OPEN-DRAFT` are `historical_complete_do_not_replay`.
   - The cursor now starts at `AUDIT-SECURITY-REMEDIATION`.

2. Added a mandatory B26 remediation sequence:
   - `AUDIT-SECURITY-REMEDIATION`
   - `AUDIT-REPOSITORY-HYGIENE`
   - `G26-AUDIT-REMEDIATION-READY`

3. Made synthetic ordering dependencies explicit in `node.dependsOn`.

4. Blocked and unranked all pre-production-only nodes:
   - `STL-504`, `STL-505`
   - G70, G80, G85, G90
   - `STOP-PRE-G70`

5. Added required dependencies to `G70-PACKET-ASSEMBLE`:
   - G30 public CMS readiness
   - G31 visitor-to-booking readiness
   - G40 proposal-to-deposit readiness
   - G50 portal/operations readiness
   - G60 measurement readiness
   - `STL-506` cutover/runbook readiness

6. Recomputed all pending-node ranks with a dependency-safe topological sort.

7. Regenerated:
   - stage-sequence edges
   - node and synthetic dependency edges
   - global serialization edges

8. Added mandatory semantic rules:
   - compiled stage DAG
   - topological rank order
   - unresolved P0-P2 findings block merge
   - exact-head Preview required

9. Strengthened the JSON Schema with record-type-specific required fields.

10. Added a standalone semantic validator covering references, DAGs, ranks, cursor, blocked gates, dependency-edge coverage, and exact serialization order.

## Repository and platform audit

### Vercel root cause

The original branch activated a multi-service topology in the existing production-linked Next.js project. Convex deployment and Next.js compilation succeeded, but the secondary service produced no Vercel-compatible `functions` or `static` output. Packaging then failed while looking for a deterministic Next routes manifest.

Context7 and official platform guidance confirmed:

- a Next.js production build owns its route manifests;
- the current Hono source shape is a valid default-exported app;
- the defect was the active Services packaging boundary, not Convex authentication or Hono application syntax.

### Repository fixes committed

- Added a failing deployment-topology contract, then made it pass.
- Restored top-level native Next.js configuration for the production-linked `website` project.
- Gated the future integrations service behind a dedicated non-production Services project and G70.
- Updated dependent CI and Convex deployment tests.
- Replaced incomplete test-secret regex escaping with a complete regular-expression escape function.
- Converted PR #169 back to draft.
- Updated the PR body with current evidence and residual blockers.

### Exact-head Vercel verification

- Deployment: `dpl_DPZH2TV321b8nJj4UAUNE6GEtw1W`
- Head: `5eb385d33976503cdac81e982ed74fbbc7f6839c`
- State: `READY`
- Framework: Next.js
- Convex Preview: `hidden-roadrunner-577`
- Build log: Next.js build passed, Convex functions deployed, and Vercel output completed.

## TDD evidence

### Deployment topology

- **RED:** the focused topology contract failed against the active multi-service configuration.
- **GREEN:** the same contract passed after isolating Services and restoring the native Next.js project contract.
- **LIVE VERIFY:** exact-head Vercel Preview is `READY`.

### Graph compiler

- **RED:** original graph semantic validation exited non-zero with 36 errors and two executable SCCs.
- **GREEN:** repaired graph validation exited zero with no parse, schema, or semantic errors.

## Convex assessment

The inspected Convex foundation is directionally sound:

- Clerk issuer configuration is environment-driven.
- Preview and production separation is retained.
- Major tenant/resource lookup indexes exist.
- The exact-head Preview successfully deployed functions to `hidden-roadrunner-577`.

This was not a production data migration or live authorization penetration test. Production mutation remains prohibited.

## Residual blockers

The Vercel packaging blocker is repaired, but PR #169 is intentionally **not merge-ready**.

Remaining work is now represented by the B26 graph nodes:

- Triage and remediate every unresolved GitHub Advanced Security and automated-review P0-P2 finding.
- Verify no tracked Python bytecode, nested Git metadata, secret material, raw PII, or machine-specific evidence paths remain.
- Repair missing runtime imports and broken skill paths.
- Run all required GitHub/security checks and the full governed repository suite.
- Reconfirm a successful Preview for the final exact head after those changes.
- Obtain independent security and architecture review.

GitHub’s combined status was still reporting Vercel as pending when checked, even though the Vercel deployment API and build logs reported the exact deployment as `READY`. The graph therefore keeps G26 blocked until GitHub checks reconcile and all remaining findings close.

## Cost impact

Original modeled total:

- Expected AI: **$89.51**
- High AI: **$164.69**
- Expected labor: **285 hours**

Audited graph total after adding mandatory remediation:

- Expected AI: **$101.51**
- High AI: **$195.69**
- Expected labor: **299 hours**

The additional budget is isolated to security remediation, repository hygiene, and independent gate verification. It prevents the much larger cost of executing a cyclic or stale graph.
