# Audited Graph Bundle

## Primary artifact

`skys-limit-sequential-tdd-execution-graph-audited.jsonl`

## Validate

```bash
python validate_stl_execution_graph.py \
  skys-limit-sequential-tdd-execution-graph-audited.jsonl \
  --schema skys-limit-sequential-tdd-execution-graph-audited.schema.json
```

A successful run exits `0` and reports:

- `ok: true`
- `schemaErrorCount: 0`
- `semanticErrorCount: 0`
- `stageDag: true`

## Rebuild from the original graph

```bash
python repair_stl_execution_graph.py \
  original.jsonl \
  skys-limit-sequential-tdd-execution-graph-audited.jsonl \
  --schema-output skys-limit-sequential-tdd-execution-graph-audited.schema.json \
  --vercel-deployment-id dpl_DPZH2TV321b8nJj4UAUNE6GEtw1W \
  --vercel-state READY
```

## Mandatory resume point

The first runnable node is `AUDIT-SECURITY-REMEDIATION`. The PR must remain draft. Production actions remain blocked until G70 receives a new explicit approval.
